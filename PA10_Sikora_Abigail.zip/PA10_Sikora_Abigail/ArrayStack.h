/* Name: Abigail Sikora
   Title: ArrayStack.h
   Purpose: templated array based stack */



#include <iostream>
#include<cstring>
using namespace std;

const size_t MAX_STACKSIZE=1000;

template<class T>
class ArrayStack;

template<class T>
ostream & operator<<(ostream & os, const ArrayStack<T> & arrayStack);

template<class T>
class ArrayStack{
	friend ostream & operator<< <>(ostream & os, const ArrayStack<T> & arrayStack);
	public:
		ArrayStack();
		ArrayStack(size_t count, const T & value);
		ArrayStack(const ArrayStack<T> & other);
		~ArrayStack();
		ArrayStack<T> & operator=(const ArrayStack<T> & rhs);
		T & top();
		const T & top() const;
		void push(const T & value);
		void pop();
		size_t size() const;
		bool empty() const;
		bool full() const;
		void clear();
		void serialize(ostream & os) const;
	private:
		T m_container[MAX_STACKSIZE];
		size_t m_top;
};
		
template<class T>
ArrayStack<T>::ArrayStack()//1 default ctor, no valid data
{
	m_top=0;
}

template<class T>
ArrayStack<T>::ArrayStack(size_t count, const T & value) //2 parameterized ctor, will hold count number of elements which each element equal to value passed in
{
	m_top=count;
	for(size_t i=0; i<count; i++)
	{
		m_container[i]=value;
	}
}

template<class T>
ArrayStack<T>::ArrayStack(const ArrayStack<T> & other) //3 copy ctor
{
	m_top=other.m_top;
	for(size_t i=0; i<m_top;i++)
	{
		m_container[i]=other.m_container[i];
	}
}

template<class T>
ArrayStack<T>::~ArrayStack() //4 destructor
{
}

template<class T>
ArrayStack<T> & ArrayStack<T>::operator=(const ArrayStack<T> & rhs) //5 operator=, assign a new value to calling object which is a copy of the rhs object passed in
{
	if(this != &rhs)
	{
		m_top=rhs.m_top;
		for(size_t i=0; i<m_top; i++)
		{
			m_container[i]=rhs.m_container[i];
		}
	}
	return *this;
}

template<class T>
T & ArrayStack<T>::top() //6a returns a reference to last inserted element 
{
	return m_container[m_top];
		
}

template<class T>
const T & ArrayStack<T>::top() const //6b returns a reference to last inserted element
{
		
	return m_container[m_top];
		
}

template<class T>
void ArrayStack<T>::push(const T & value) //7 push, inserts value at top of the stack
{
	if(!full())
	{
		m_top++;
		m_container[m_top]=value;
	}
}

template<class T>
void ArrayStack<T>::pop() //8 removes the top element of the stack
{
	if(!empty())
	{
		m_top--;
	}
}

template<class T>
size_t ArrayStack<T>::size() const //9 returns the size of the stack
{
	return m_top;
}

template<class T>
bool ArrayStack<T>::empty() const //10 sees if stack is empty or not
{
	if(m_top==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

template<class T>
bool ArrayStack<T>::full() const //11 checks to see if stack is full or not
{
	if(m_top==MAX_STACKSIZE)
	{
		return true;
	}
	else
	{
		return false;
	}
}

template<class T>
void ArrayStack<T>::clear() //12 after this function is called, stack will be considered empty
{
	m_top=0;
}

template<class T>
void ArrayStack<T>::serialize(ostream & os) const //13 outputs complete content of ArrayStack
{
	for(size_t i=0; i<m_top;i++)
	{
		os << m_container[i] << endl;
	}
}

template<class T>
ostream & operator<<(ostream & os, const ArrayStack<T> & arrayStack)// i outputs the complete content of ArrayStack
{
	arrayStack.serialize(os);
	return os;
}








	


















