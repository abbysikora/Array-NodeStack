// Name: Abigail Sikora
// Title: proj10.cpp
// Purpose: test driver for the templated classes of ArrayStack and NodeStack



#include<iostream>
#include<cstring>
using namespace std;

#include "ArrayStack.h"
#include "NodeStack.h"

int main()
{
	cout << "TESTING ARRAYSTACK WITH INT" << endl;

	cout<< "TESTING DEFAULT CTOR" << endl;
	ArrayStack<int> arrstack;
	cout << arrstack << endl;

	cout << "TESTING PARAMETERIZED CTOR" << endl;
	ArrayStack<int> arrstack1(5, 10);
	cout << arrstack1 << endl;

	cout << "TESTING COPY CTOR" << endl;
	ArrayStack<int> arraycpy(arrstack1);
	cout << arraycpy << endl;

	cout << "TESTING OPERATOR=" << endl;
	ArrayStack<int> arrayequals;
	arrayequals=arrstack1;
	cout << arrayequals << endl;

	cout << "TESTING POP FUNCTION" << endl;
	arrstack1.pop();
	cout << arrstack1 << endl;

	cout << "TESTING PUSH FUNCTION" << endl;
	arrstack1.push(10);
	cout << arrstack1 << endl;

	cout << "TESTING SIZE FUNCTION" << endl;
	cout << arrstack1.size() << endl;
	
	cout << "TESTING CLEAR FUNCTION" << endl;
	arrstack1.clear();
	cout << arrstack1 << endl;

	cout <<"FULL, TOP, AND EMPTY WERE USED IN THESE TESTS!" << endl;

	cout << "TESTING ARRAYSTACK WITH CHAR" << endl;

	cout<< "TESTING DEFAULT CTOR" << endl;
	ArrayStack<char> arrstackchar;
	cout << arrstackchar << endl;

	cout << "TESTING PARAMETERIZED CTOR" << endl;
	ArrayStack<char> arrstack2(5, 'a');
	cout << arrstack2 << endl;

	cout << "TESTING COPY CTOR" << endl;
	ArrayStack<char> arraycpychar(arrstack2);
	cout << arraycpychar << endl;

	cout << "TESTING OPERATOR=" << endl;
	ArrayStack<char> arrayequalschar;
	arrayequalschar=arrstack2;
	cout << arrayequalschar << endl;

	cout << "TESTING POP FUNCTION" << endl;
	arrstack2.pop();
	cout << arrstack2 << endl;

	cout << "TESTING PUSH FUNCTION" << endl;
	arrstack2.push('a');
	cout << arrstack2 << endl;

	cout << "TESTING SIZE FUNCTION" << endl;
	cout << arrstack2.size() << endl;
	
	cout << "TESTING CLEAR FUNCTION" << endl;
	arrstack2.clear();
	cout << arrstack2 << endl;

	cout <<"FULL, TOP, AND EMPTY WERE USED IN THESE TESTS!" << endl;

	cout << "TESTING NODESTACK WITH INT" << endl;

	cout<< "TESTING DEFAULT CTOR" << endl;
	NodeStack<int> nodestack;
	cout << nodestack << endl;

	cout << "TESTING PARAMETERIZED CTOR" << endl;
	NodeStack<int> nodestack1(5, 10);
	cout << nodestack1 << endl;

	cout << "TESTING COPY CTOR" << endl;
	NodeStack<int> nodecpy(nodestack1);
	cout << nodecpy << endl;

	cout << "TESTING OPERATOR=" << endl;
	NodeStack<int> nodeequals;
	nodeequals=nodestack1;
	cout << nodeequals << endl;

	cout << "TESTING POP FUNCTION" << endl;
	nodestack1.pop();
	cout << nodestack1 << endl;

	cout << "TESTING PUSH FUNCTION" << endl;
	nodestack1.push(10);
	cout << nodestack1 << endl;

	cout << "TESTING SIZE FUNCTION" << endl;
	cout << nodestack1.size() << endl;
	
	cout << "TESTING CLEAR FUNCTION" << endl;
	nodestack1.clear();
	cout << nodestack1 << endl;

	cout <<"FULL, TOP, AND EMPTY WERE USED IN THESE TESTS!" << endl;

	cout << "TESTING NODESTACK WITH CHAR" << endl;

	cout<< "TESTING DEFAULT CTOR" << endl;
	NodeStack<char> nodestackchar;
	cout << nodestackchar << endl;

	cout << "TESTING PARAMETERIZED CTOR" << endl;
	NodeStack<char> nodestack2(5, 'a');
	cout << nodestack2 << endl;

	cout << "TESTING COPY CTOR" << endl;
	NodeStack<char> nodecpychar(nodestack2);
	cout << nodecpy << endl;

	cout << "TESTING OPERATOR=" << endl;
	NodeStack<char> nodeequalschar;
	nodeequalschar=nodestack2;
	cout << nodeequalschar << endl;

	cout << "TESTING POP FUNCTION" << endl;
	nodestack2.pop();
	cout << nodestack2 << endl;

	cout << "TESTING PUSH FUNCTION" << endl;
	nodestack2.push('a');
	cout << nodestack2 << endl;

	cout << "TESTING SIZE FUNCTION" << endl;
	cout << nodestack2.size() << endl;
	
	cout << "TESTING CLEAR FUNCTION" << endl;
	nodestack2.clear();
	cout << nodestack2 << endl;

	cout <<"FULL, TOP, AND EMPTY WERE USED IN THESE TESTS!" << endl;


	
return 0;
}
