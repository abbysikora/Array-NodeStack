/* Name: Abigail Sikora
   Title: NodeStack.h
   Purpose: templated Node based stack */


#include<iostream>
#include<cstring> 
using namespace std;

template<class T>
class NodeStack;

template<class T>
class Node{
	friend class NodeStack<T>;
	public:
		Node():m_next(NULL){}
		Node(const T & data, Node<T> * next=NULL):m_next(next), m_data(data){}
		T & data(){return m_data;}
		const T & data() const{return m_data;}
	private:
		Node<T> * m_next;
		T m_data;
};

template<class T>
ostream & operator<<(ostream & os, const NodeStack<T> & nodeStack);

template<class T>
class NodeStack{
	friend ostream & operator<< <>(ostream & os, const NodeStack<T> & nodeStack);
	public:
		NodeStack();
		NodeStack(size_t count, const T & value);
		NodeStack(const NodeStack<T> & other);
		~NodeStack();
		NodeStack<T> & operator=(const NodeStack<T> & rhs);
		T & top();
		const T & top() const;
		void push(const T & value);
		void pop();
		size_t size() const;
		bool empty() const;
		bool full() const;
		void clear();
		void serialize(ostream & os) const;
	private:
		Node<T> * m_top;
};

template<class T>
NodeStack<T>::NodeStack() //1 default ctor, has no elements 
{
	m_top=NULL;
}

template<class T>
NodeStack<T>::NodeStack(size_t count, const T & value) //2 parameterized ctor
{
	m_top=new Node<T>(value);
	Node<T> * temp=m_top;
	for(;count>1; --count)
	{
		temp=new Node<T>(value);
		temp->m_next=m_top;
		m_top=temp;
	}
	temp=NULL;
}

template<class T>
NodeStack<T>::NodeStack(const NodeStack<T> & other) //3 copy ctor
{	
	if(m_top)
	{
		clear();
	}
	if(!other.m_top)
	{
		m_top=NULL;
	}
	else if(!other.m_top->m_next)
	{
		m_top=new Node<T>(other.m_top->data());
	}
	else
	{
		Node<T> * othercurr=other.m_top;
		m_top=new Node<T>(othercurr->m_data);
		Node<T> * curr=m_top;
		othercurr=othercurr->m_next;
		while(othercurr)
		{
			curr->m_next=new Node<T>(othercurr->m_data);
			curr=curr->m_next;
			othercurr=othercurr->m_next;
		}
		curr=NULL;
		othercurr=NULL;
	}
	
}

template<class T>
NodeStack<T>::~NodeStack() //4 dtor
{
	clear();
}

template<class T>
NodeStack<T> & NodeStack<T>::operator=(const NodeStack<T> & rhs) //5, assigns a new value to the calling NodeStack object
{
	if(this != &rhs)
	{
		if(m_top)
		{
			clear();
		}
		if(!rhs.m_top)
		{
			m_top=NULL;
		}
		else if(!rhs.m_top->m_next)
		{
			m_top=new Node<T>(rhs.m_top->data());
		}
		else
		{
			Node<T> * rhscurr=rhs.m_top;
			m_top=new Node<T>(rhscurr->m_data);
			Node<T> * curr=m_top;
			rhscurr=rhscurr->m_next;
			while(rhscurr)
			{
				curr->m_next=new Node<T>(rhscurr->m_data);
				curr=curr->m_next;
				rhscurr=rhscurr->m_next;
			}
			curr=NULL;
			rhscurr=NULL;
		}
	}
	return *this;
}

template<class T>
T & NodeStack<T>::top()//6a reutrns a reference to top element of the stack
{
	if(!empty())
	{
		return m_top->data();
	}
}

template<class T>
const T & NodeStack<T>::top() const//6b reutrns a reference to top element of the stack
{
	if(!empty())
	{
		return m_top->data();
	}
}

template<class T>
void NodeStack<T>::push(const T & value) //7 push, inserts value at top of stack
{
	if(m_top==NULL)
	{
		m_top=new Node<T>(value);
	}
	else
	{
		Node<T> * temp=new Node<T>(value);
		temp->m_next=m_top;
		m_top=temp;
		temp=NULL;
	}
}

template<class T>
void NodeStack<T>::pop() //8 pop, removes top element of the stack
{
	if(!m_top->m_next)
	{
		delete m_top;
		m_top=NULL;
	}
	else if(m_top)
	{
		Node<T> * temp=m_top;
		m_top=m_top->m_next;
		delete temp;
		temp=NULL;
	}
}

template<class T>
size_t NodeStack<T>::size() const //9 returns the current size of the stack
{
	size_t size=0;
	if(m_top)
	{
		for(Node<T> * curr=m_top; curr!=NULL; curr=curr->m_next)
		{
			size++;
		}
		
	}
	return size;
}


template<class T>
bool NodeStack<T>::empty() const //10 sees if NodeStack is empty or not
{
	if(m_top==NULL)
	{
		return true;
	}
	else
	{
		return false;
	}
}

template<class T>
bool NodeStack<T>::full() const//11 always returns false
{
	return false;
}

template<class T>
void NodeStack<T>::clear() //12 stack will be considered empty after this function is called
{
	if(m_top)
	{
		Node<T> * del=m_top;
		while(m_top)
		{
			m_top=m_top->m_next;
			del->m_next=NULL;
			delete del;
			del=m_top;
		}
		del=NULL;
	}
}

template<class T>
void NodeStack<T>::serialize(ostream & os) const //13
{
	for(Node<T> * curr=m_top; curr!=NULL; curr=curr->m_next)
	{
		os << curr->data() << endl;
	}
}

template<class T>
ostream & operator<<(ostream & os, const NodeStack<T> & nodeStack)// i outputs the complete content of NodeStack
{
	nodeStack.serialize(os);
	return os;
}




		





